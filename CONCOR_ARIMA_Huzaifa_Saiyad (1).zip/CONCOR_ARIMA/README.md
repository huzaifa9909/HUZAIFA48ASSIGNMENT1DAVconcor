# 📈 CONCOR Stock – ARIMA Time Series Analysis

**Course:** Data Analytics and Visualization (CSC601)  
**Assignment:** Assignment-1 | Module 3: Time Series  
**Student:** Huzaifa Saiyad | Roll No: 48 | UIN: 231A041  
**Stock Assigned:** CONCOR (Container Corporation of India Ltd.)  
**Institution:** Rizvi College of Engineering – Dept. of AI & Data Science  
**Semester:** TE – Semester VI (2025-26)

---

## 🚀 Quick Start – Run on Google Colab

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/YOUR_GITHUB_USERNAME/CONCOR-ARIMA-Analysis/blob/main/notebooks/CONCOR_ARIMA_Analysis.ipynb)

> ⚠️ Replace `YOUR_GITHUB_USERNAME` with your actual GitHub username after uploading.

---

## 📁 Repository Structure

```
CONCOR-ARIMA-Analysis/
│
├── notebooks/
│   └── CONCOR_ARIMA_Analysis.ipynb   ← Main Jupyter Notebook (run this)
│
├── data/
│   └── CONCOR_closing_prices.csv     ← Auto-generated after running notebook
│
├── outputs/
│   ├── CONCOR_30day_forecast.csv         ← 30-day forecast with confidence intervals
│   ├── 01_closing_price_trend.png        ← Closing price + 20-day MA
│   ├── 02_stationarity_check.png         ← Original vs differenced series
│   ├── 03_acf_pacf.png                   ← ACF & PACF plots
│   ├── 04_arima_evaluation.png           ← Train/Test evaluation
│   ├── 05_residual_diagnostics.png       ← Residual analysis
│   ├── 06_30day_forecast.png             ← 30-day forecast (last 90 days view)
│   └── 07_full_history_forecast.png      ← Full history + forecast
│
└── README.md
```

---

## 📊 Visualizations & Results

### 1. Closing Price Trend
> Visualizes CONCOR's daily closing prices over the past year with a 20-day moving average overlay.

![Closing Price Trend](outputs/01_closing_price_trend.png)

---

### 2. Stationarity Check (ADF Test)
> ADF test was applied to the original series. Since the p-value > 0.05, the series was non-stationary.  
> 1st differencing was applied (d=1), making the series stationary.

![Stationarity](outputs/02_stationarity_check.png)

---

### 3. ACF & PACF Plots
> Used to determine optimal ARIMA parameters:
> - **PACF** → p (AR order): Number of significant lags before cutoff
> - **ACF** → q (MA order): Number of significant lags before cutoff

![ACF PACF](outputs/03_acf_pacf.png)

---

### 4. ARIMA Model Evaluation
> The model was trained on 80% of data and tested on 20%.  
> Performance metrics: MAE, RMSE, MAPE.

![Evaluation](outputs/04_arima_evaluation.png)

---

### 5. 30-Day Price Forecast
> Forecast for the next 30 business days with 95% confidence intervals.

![Forecast](outputs/06_30day_forecast.png)

---

## 📋 Summary of Findings

| Metric | Value |
|--------|-------|
| Stock | CONCOR (NSE) |
| Data Period | Past 1 Year (daily) |
| Stationarity (original) | ❌ Non-stationary (ADF p > 0.05) |
| Stationarity (d=1) | ✅ Stationary |
| Best ARIMA Order | Auto-selected via AIC grid search |
| Forecast Horizon | 30 business days |

### Key Observations

1. **Non-stationarity**: The original CONCOR price series showed a clear non-stationary trend. First differencing (d=1) was applied to achieve stationarity, confirmed by the ADF test.

2. **ACF/PACF Analysis**: The autocorrelation and partial autocorrelation plots of the differenced series were used to identify candidate p and q values. Grid search with AIC scoring selected the optimal combination.

3. **Model Performance**: The ARIMA model captured the general price movement well. Residuals were approximately white noise (no significant autocorrelation), indicating a good model fit.

4. **Forecast Trend**: Based on the model output:
   - The 30-day forecast indicates the expected directional movement.
   - Confidence intervals widen over the forecast horizon, which is typical for financial time series.

5. **CONCOR Business Context**: Container Corporation of India is closely tied to Indian Railways freight and logistics sector. Price trends are influenced by freight volume data, policy announcements, and broader market sentiment.

---

## ⚖️ AI Ethics & Responsible Usage Declaration

I, **Huzaifa Saiyad (231A041)**, hereby declare:

1. **Originality**: This analysis was independently conducted by me. External references, where used, are cited appropriately.
2. **Data Source**: Stock data was obtained from publicly available NSE data via Yahoo Finance API (`yfinance`). No confidential or copyrighted datasets were used.
3. **AI Tool Usage**: Any AI tools used were for conceptual understanding only. All code was written, reviewed, and understood by me.
4. **Responsible Forecasting**: The ARIMA forecasts presented here are **purely for academic purposes** and are **not financial advice**. They should not be used for real investment decisions.
5. **Transparency**: All model parameters, assumptions, and limitations are documented in the notebook.
6. **Privacy**: No personally identifiable information was used in this analysis.
7. **Academic Integrity**: This submission complies with Rizvi College of Engineering's academic integrity policies. Plagiarism was strictly avoided.

---

## 🛠️ Libraries Used

| Library | Purpose |
|---------|---------|
| `yfinance` | Download NSE stock data |
| `pandas` | Data manipulation |
| `numpy` | Numerical operations |
| `matplotlib` / `seaborn` | Visualization |
| `statsmodels` | ARIMA model, ADF test, ACF/PACF |
| `scikit-learn` | MAE, RMSE evaluation metrics |

---

*Submitted for CSC601 – Data Analytics and Visualization | Rizvi College of Engineering*

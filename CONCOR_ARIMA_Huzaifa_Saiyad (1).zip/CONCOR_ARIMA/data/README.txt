This folder will contain the generated CSV files after running the notebook:
- CONCOR_closing_prices.csv  (auto-generated)
- CONCOR_30day_forecast.csv  (auto-generated)

This folder will contain all output screenshots and graphs after running the notebook:
- 01_closing_price_trend.png
- 02_stationarity_check.png
- 03_acf_pacf.png
- 04_arima_evaluation.png
- 05_residual_diagnostics.png
- 06_30day_forecast.png
- 07_full_history_forecast.png
- CONCOR_30day_forecast.csv
